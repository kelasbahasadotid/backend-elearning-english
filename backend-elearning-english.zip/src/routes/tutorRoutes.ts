import { Router as ExpressRouter } from 'express';
import { getStudentSubmissions, submitTutorReview } from '../controllers/tutorController';
import {
  getAllLessons, getLessonsByCourse, createLesson, updateLesson, deleteLesson,
  getLessonContents, getLessonContentAttachments, createLessonContent, updateLessonContent, deleteLessonContent, reorderLessonContents,
  getAllQuizzes, createQuiz, updateQuiz, deleteQuiz,
  getQuizQuestions, createQuizQuestion, updateQuizQuestion, deleteQuizQuestion,
  createQuestionOption, updateQuestionOption, deleteQuestionOption, saveMatchingPairs
} from '../controllers/adminController';
import { authenticateToken, requireRole } from '../middleware/auth';

const router = ExpressRouter();

// Require logged-in user and administrative/tutor roles (SUPER_ADMIN=1, ADMIN=2, TUTOR=3)
router.use(authenticateToken as any);
router.use(requireRole([1, 2, 3]) as any);

// Tutor submissions & reviews
router.get('/submissions', getStudentSubmissions);
router.post('/submissions/:attemptId/review', submitTutorReview);

// Lessons Management for Tutor
router.get('/lessons', getAllLessons);
router.get('/courses/:id/lessons', getLessonsByCourse);
router.post('/lessons', createLesson);
router.put('/lessons/:id', updateLesson);
router.delete('/lessons/:id', deleteLesson);

// Lesson Content Management for Tutor
router.get('/lessons/:lessonId/contents', getLessonContents);
router.get('/lessons/contents/:id/attachments', getLessonContentAttachments);
router.post('/lessons/:lessonId/contents', createLessonContent);
router.post('/lessons/:lessonId/contents/reorder', reorderLessonContents);
router.put('/lessons/contents/:id', updateLessonContent);
router.delete('/lessons/contents/:id', deleteLessonContent);

// Quizzes & Questions Management for Tutor
router.get('/quizzes', getAllQuizzes);
router.post('/quizzes', createQuiz);
router.put('/quizzes/:id', updateQuiz);
router.delete('/quizzes/:id', deleteQuiz);

router.get('/quizzes/:quizId/questions', getQuizQuestions);
router.post('/quizzes/:quizId/questions', createQuizQuestion);
router.put('/quizzes/questions/:questionId', updateQuizQuestion);
router.delete('/quizzes/questions/:questionId', deleteQuizQuestion);

// Options & Matching Pairs for Tutor
router.post('/quizzes/questions/:questionId/options', createQuestionOption);
router.post('/quizzes/questions/:questionId/matching-pairs', saveMatchingPairs);
router.put('/quizzes/questions/options/:optionId', updateQuestionOption);
router.delete('/quizzes/questions/options/:optionId', deleteQuestionOption);

export default router;
